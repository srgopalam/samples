package com.example.demoOne;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.client.ClientHttpRequestFactory;
import org.springframework.http.client.SimpleClientHttpRequestFactory;
import org.springframework.web.client.RestTemplate;

import javax.net.ssl.HttpsURLConnection;
import javax.net.ssl.SSLContext;
import javax.net.ssl.TrustManagerFactory;
import java.io.FileInputStream;
import java.security.KeyStore;
import java.security.SecureRandom;
import java.security.cert.CertificateFactory;
import java.security.cert.X509Certificate;

@Configuration
public class RestTemplateConfig {

    @Bean
    public RestTemplate restTemplate() throws Exception {
        // Load the SSL certificate
        CertificateFactory certificateFactory = CertificateFactory.getInstance("X.509");
        FileInputStream certificateFile = new FileInputStream("src/main/resources/certificate.crt");
        X509Certificate certificate = (X509Certificate) certificateFactory.generateCertificate(certificateFile);

        // Create a TrustManager that trusts the SSL certificate
        KeyStore trustStore = KeyStore.getInstance(KeyStore.getDefaultType());
        trustStore.load(null);
        trustStore.setCertificateEntry("custom", certificate);
        TrustManagerFactory trustManagerFactory = TrustManagerFactory.getInstance(TrustManagerFactory.getDefaultAlgorithm());
        trustManagerFactory.init(trustStore);

        SSLContext sslContext = SSLContext.getInstance("TLS");
        sslContext.init(null, trustManagerFactory.getTrustManagers(), new SecureRandom());

        // Create a ClientHttpRequestFactory with SSL configuration
        HttpsURLConnection.setDefaultSSLSocketFactory(sslContext.getSocketFactory());
        ClientHttpRequestFactory factory = new SimpleClientHttpRequestFactory();

        return new RestTemplate(factory);
    }
}
