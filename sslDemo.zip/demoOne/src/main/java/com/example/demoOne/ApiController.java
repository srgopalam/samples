package com.example.demoOne;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.oauth2.client.OAuth2AuthorizedClient;
import org.springframework.security.oauth2.client.annotation.RegisteredOAuth2AuthorizedClient;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.client.RestTemplate;

@Controller
public class ApiController {

    private final RestTemplate restTemplate;

    @Autowired
    public ApiController(RestTemplate restTemplate) {
        this.restTemplate = restTemplate;
    }

    @GetMapping("/")
    public String callApi(@RegisteredOAuth2AuthorizedClient("my-api-client") OAuth2AuthorizedClient authorizedClient, Model model) {
        String apiUrl = "https://api.example.com/resource";
        ResponseEntity<String> response = restTemplate.getForEntity(apiUrl, String.class);
        model.addAttribute("response", response.getBody());
        return "response";
    }
}
