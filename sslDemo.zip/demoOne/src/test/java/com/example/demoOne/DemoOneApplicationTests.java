package com.example.demoOne;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DemoOneApplicationTests {

	@Test
	void contextLoads() {
	}

}
