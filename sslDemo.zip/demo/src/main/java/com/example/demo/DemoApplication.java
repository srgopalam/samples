package com.example.demo;

import java.io.FileInputStream;
import java.io.IOException;
import java.security.KeyStore;
import java.security.SecureRandom;
import java.security.cert.X509Certificate;
import java.util.ArrayList;
import java.util.List;

import javax.net.ssl.SSLContext;
import javax.net.ssl.TrustManager;
import javax.net.ssl.X509TrustManager;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;
import org.springframework.http.client.ClientHttpRequestInterceptor;
import org.springframework.http.client.SimpleClientHttpRequestFactory;
import org.springframework.util.ResourceUtils;
import org.springframework.web.client.RestTemplate;

@SpringBootApplication
public class DemoApplication {

	public static void main(String[] args) {
		SpringApplication.run(DemoApplication.class, args);
	}

	@Bean
	RestTemplate restTemplate() throws Exception {
		// Load the SSL certificate from the keystore
		KeyStore keyStore = KeyStore.getInstance("PKCS12");
		keyStore.load(new FileInputStream(ResourceUtils.getFile("classpath:keystore.p12")),
				"somepass".toCharArray());

		// Create SSL context with custom trust manager
		SSLContext sslContext = SSLContext.getInstance("TLS");
		sslContext.init(null, new TrustManager[] { new X509TrustManager() {
			public X509Certificate[] getAcceptedIssuers() {
				return null;
			}

			public void checkClientTrusted(X509Certificate[] certs, String authType) {
			}

			public void checkServerTrusted(X509Certificate[] certs, String authType) {
			}
		} }, new SecureRandom());

		// Create a RestTemplate with SSL context
		RestTemplate restTemplate = new RestTemplate(new SimpleClientHttpRequestFactory() {
			@Override
			protected void prepareConnection(java.net.HttpURLConnection connection, String httpMethod)
					throws IOException {
				if (connection instanceof javax.net.ssl.HttpsURLConnection) {
					javax.net.ssl.HttpsURLConnection httpsConnection = (javax.net.ssl.HttpsURLConnection) connection;
					httpsConnection.setSSLSocketFactory(sslContext.getSocketFactory());
				}
				super.prepareConnection(connection, httpMethod);
			}
		});

		// Add OAuth token header
		List<ClientHttpRequestInterceptor> interceptors = new ArrayList<>();
		interceptors.add((request, body, execution) -> {
			request.getHeaders().set("Authorization", "Bearer your-oauth-token-here");
			return execution.execute(request, body);
		});

		restTemplate.setInterceptors(interceptors);

		return restTemplate;
	}
}
